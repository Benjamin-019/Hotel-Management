
# Pratoverde Hotels

1) Install wamp server
https://sourceforge.net/projects/wampserver/files/WampServer%202/Wampserver%202.5/

2) Unzip PratoverdeHotels.zip and copy the extracted folder into the folder C: \ wamp \ www

3) Start the Wamp services (wait until the icon at the bottom a right is green)

4) In your browser, type: http: // localhost / phpmyadmin /

5) Create a new database called "pratoverde hotels" (exact name)

6) Click on import and click on the sql file: pratoverde_hotels.sql

7) In your browser, type: http: //localhost/PratoverdeHotels/home.php